import RestoDbSource from '../../data/restodb-source';
import UrlParser from '../../routes/url-parser';
import { createRestoDetailTemplate } from '../templates/template-creator';
import LikeButtonInitiator from '../../utils/like-button-initiator';
import swal from 'sweetalert';

const Detail = {
  async render() {
    return `
      <div id="kuliner" class="kuliner"></div>
      <div id="likeButtonContainer"></div>
    `;
  },

  async afterRender() {
    const url = UrlParser.parseActiveUrlWithoutCombiner();
    const restoContainer = document.querySelector('#kuliner');

    try {
      const restaurantData = await RestoDbSource.detail(url.id);

      if (restaurantData && restaurantData.id) {
        // Data valid
        restoContainer.innerHTML = createRestoDetailTemplate(restaurantData);

        LikeButtonInitiator.init({
          likeButtonContainer: document.querySelector('#likeButtonContainer'),
          restaurant: {
            id: restaurantData.id,
            name: restaurantData.name,
            city: restaurantData.city,
            address: restaurantData.address,
            rating: restaurantData.rating,
            pictureId: restaurantData.pictureId,
          },
        });
      } else {
        // Data tidak ditemukan
        restoContainer.innerHTML = `
          <p>Informasi restoran tidak tersedia atau tidak valid.</p>
        `;
        swal({
          title: 'Tidak Ditemukan',
          text: 'Informasi restoran tidak dapat ditemukan.',
          icon: 'warning',
        });
      }
    } catch (err) {
      // Kesalahan dalam pengambilan data
      console.error('Error:', err);
      restoContainer.innerHTML = `
        <p>Maaf, terjadi gangguan saat memuat data restoran. Coba periksa koneksi Anda.</p>
      `;
      swal({
        title: 'Kesalahan',
        text: 'Gagal memuat data restoran.',
        icon: 'error',
      });
    }
  },
};

export default Detail;
