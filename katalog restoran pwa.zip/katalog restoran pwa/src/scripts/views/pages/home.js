import RestoDbSource from '../../data/restodb-source';
import { createRestoItemTemplate } from '../templates/template-creator';

const Home = {
  async render() {
    return `
      <div class="hero">
        <div class="hero_inner"></div>
      </div>
      <br>
      <h1 class="judul">Selamat Datang di Website Kuliner</h1>
      <p class="desc-home">Mari nikmati sajian terbaik tanpa batas</p>
      <br>
      <div class="content">
        <div id="kuliner" class="kuliner"></div>
      </div>
    `;
  },

  async afterRender() {
    try {
      const restaurants = await RestoDbSource.home();
      const kulinerContainer = document.querySelector('#kuliner');

      if (restaurants.length > 0) {
        // Jika ada restoran yang tersedia
        restaurants.forEach((restaurant) => {
          kulinerContainer.innerHTML += createRestoItemTemplate(restaurant);
        });
      } else {
        // Jika tidak ada data restoran
        kulinerContainer.innerHTML = `
          <p>Tidak ada restoran yang tersedia untuk ditampilkan.</p>
        `;
      }
    } catch (error) {
      // Jika terjadi kesalahan dalam pengambilan data
      console.error('Error saat memuat data:', error);
      const kulinerContainer = document.querySelector('#kuliner');
      kulinerContainer.innerHTML = `
        <p>Maaf, terjadi kesalahan saat memuat data restoran. Silakan coba lagi nanti.</p>
      `;
    }
  },
};

export default Home;
