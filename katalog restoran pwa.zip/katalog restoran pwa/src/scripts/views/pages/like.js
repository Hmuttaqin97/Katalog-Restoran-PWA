import FavoriteRestoIdb from '../../data/favorite-resto-idb';
import { createRestoItemTemplate } from '../templates/template-creator';

const Like = {
  async render() {
    return `
      <div class="content">
        <h2 class="content__heading">Restoran Favorit Anda</h2>
        <div id="favoriteResto" class="resto-list"></div>
      </div>
    `;
  },

  async afterRender() {
    try {
      const favoriteRestaurants = await FavoriteRestoIdb.getAllResto();
      const favoriteRestoContainer = document.querySelector('#favoriteResto');

      if (favoriteRestaurants.length > 0) {
        // Jika terdapat restoran favorit
        favoriteRestaurants.forEach((restaurant) => {
          favoriteRestoContainer.innerHTML += createRestoItemTemplate(restaurant);
        });
      } else {
        // Jika tidak ada restoran favorit
        favoriteRestoContainer.innerHTML = `
          <p class="no-data">Belum ada restoran yang Anda sukai. Cobalah untuk menambahkan beberapa favorit!</p>
        `;
      }
    } catch (error) {
      // Jika terjadi kesalahan dalam memuat data
      console.error('Terjadi kesalahan saat memuat restoran favorit:', error);
      const favoriteRestoContainer = document.querySelector('#favoriteResto');
      favoriteRestoContainer.innerHTML = `
        <p class="error-message">Maaf, kami tidak dapat memuat data restoran favorit Anda saat ini. Silakan coba lagi nanti.</p>
      `;
    }
  },
};

export default Like;
